package br.edu.ifpe.aquarelapapelaria.data.local

// Fronteira: acesso ao banco para a tabela "movimentacoes_estoque". Só consultas SQL; sem regra de negócio.

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import br.edu.ifpe.aquarelapapelaria.model.MovimentacaoEstoque
import kotlinx.coroutines.flow.Flow

@Dao
interface MovimentacaoEstoqueDao {

    @Insert
    suspend fun inserir(movimentacao: MovimentacaoEstoque): Long

    @Query("SELECT * FROM movimentacoes_estoque ORDER BY data DESC")
    fun listarTodas(): Flow<List<MovimentacaoEstoque>>

    @Query("SELECT * FROM movimentacoes_estoque WHERE materialId = :materialId ORDER BY data DESC")
    fun listarPorMaterial(materialId: Long): Flow<List<MovimentacaoEstoque>>

    @Query("SELECT * FROM movimentacoes_estoque WHERE pedidoId = :pedidoId ORDER BY data DESC")
    fun listarPorPedido(pedidoId: Long): Flow<List<MovimentacaoEstoque>>
}
